def numberOfOccurrencesInString():
    return
