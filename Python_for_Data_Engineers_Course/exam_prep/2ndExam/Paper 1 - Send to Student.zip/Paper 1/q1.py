def minimumWage():
    return
