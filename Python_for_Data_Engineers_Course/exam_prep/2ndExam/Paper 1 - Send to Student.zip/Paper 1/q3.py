def percentageUnderTenPounds():
    return
