def longestPalindrome():
    return
