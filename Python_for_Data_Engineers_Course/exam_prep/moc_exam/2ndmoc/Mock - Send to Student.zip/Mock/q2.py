def calculateFactorial():
    return
