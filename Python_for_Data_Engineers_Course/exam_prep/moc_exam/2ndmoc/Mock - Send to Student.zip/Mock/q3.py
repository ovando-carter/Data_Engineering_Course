def countWords():
    return
