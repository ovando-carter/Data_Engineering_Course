def findDuplicates():
    return
