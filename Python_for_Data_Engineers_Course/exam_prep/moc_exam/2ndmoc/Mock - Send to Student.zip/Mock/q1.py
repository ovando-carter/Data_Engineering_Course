def rightAngledTriangle():
    return
