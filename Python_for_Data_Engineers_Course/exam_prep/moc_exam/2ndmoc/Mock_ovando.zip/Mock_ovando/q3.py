def countWords(wordString):
    wordString = wordString.lower()
    x= wordString.split()
    count = 0
    for entry in x: 
        if entry[-1] == 'r' or entry[-1] == 's':
            count += 1
    return count